require('dotenv').config();
const express = require('express');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const OpenAI = require('openai');
const Anthropic = require('@anthropic-ai/sdk');

const app = express();
const PORT = process.env.PORT || 3000;

// ── Clients ─────────────────────────────────────────────────────────────────
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

// ── Multer – temp upload to disk ─────────────────────────────────────────────
const upload = multer({
  dest: 'uploads/',
  limits: { fileSize: 500 * 1024 * 1024 }, // 500 MB
  fileFilter: (_req, file, cb) => {
    const allowed = [
      'audio/mpeg', 'audio/mp3', 'audio/mp4', 'audio/wav',
      'audio/webm', 'audio/ogg', 'audio/flac', 'audio/m4a',
      'video/mp4', 'video/webm', 'video/mpeg', 'video/quicktime',
      'application/octet-stream',
    ];
    // also allow by extension when MIME is generic
    const ext = path.extname(file.originalname).toLowerCase();
    const allowedExt = ['.mp3', '.mp4', '.m4a', '.wav', '.webm', '.ogg',
                        '.flac', '.mpeg', '.mpga', '.mov'];
    if (allowed.includes(file.mimetype) || allowedExt.includes(ext)) {
      cb(null, true);
    } else {
      cb(new Error(`סוג קובץ לא נתמך: ${file.mimetype}`));
    }
  },
});

// ── Static frontend ──────────────────────────────────────────────────────────
app.use(express.static('public'));
app.use(express.json());

// ── Helper: delete file silently ─────────────────────────────────────────────
function cleanup(filePath) {
  fs.unlink(filePath, () => {});
}

// ── Helper: escape CSV cell ───────────────────────────────────────────────────
function csvCell(value) {
  if (value === null || value === undefined) return '""';
  const str = String(value).replace(/"/g, '""');
  return `"${str}"`;
}

// ── Claude prompt ─────────────────────────────────────────────────────────────
function buildPrompt(transcription, filename, durationSec) {
  const durationStr = durationSec
    ? `${Math.floor(durationSec / 60)}:${String(Math.floor(durationSec % 60)).padStart(2, '0')}`
    : 'לא ידוע';

  return `אתה עוזר לארכיון ראיונות של מרב מיכאלי, חברת הכנסת ויו"ר מפלגת העבודה.
עליך לנתח את התמלול הבא ולמלא 13 שדות מדויקים עבור טבלת ארכיון.

שם הקובץ המקורי: ${filename}
משך הקובץ: ${durationStr}

--- תמלול ---
${transcription}
--- סוף תמלול ---

החזר JSON בלבד (ללא תגיות markdown, ללא טקסט נוסף) עם המבנה הבא:

{
  "נושא_ראשי": "נושא הליבה של הראיון – משפט אחד תמציתי",
  "תאריך_שידור": "תאריך בפורמט DD/MM/YYYY אם מוזכר בתמלול, אחרת ריק",
  "מדיה": "טלוויזיה / רדיו / פודקאסט / אינטרנט / עיתון / אחר",
  "גוף_תקשורת": "שם הערוץ, הרדיו, האתר או העיתון",
  "שם_התכנית": "שם התכנית אם מוזכר, אחרת ריק",
  "סוג_אייטם": "ראיון / פאנל / ויכוח / נאום / ריאיון עיתונאי / אחר",
  "מראיין": "שם המראיין/ת אם ניתן לזהות, אחרת ריק",
  "סיווג": "חיובי / שלילי / ניטרלי / מעורב – מבחינת סיקור מרב מיכאלי",
  "נושאים": "רשימת נושאים מופרדים בפסיק (עד 6)",
  "מילות_מפתח": "מילות מפתח ממוקדות מופרדות בפסיק (עד 8)",
  "ניימדרופינג": "שמות של אנשים / מפלגות / ארגונים שהוזכרו, מופרדים בפסיק",
  "משך": "${durationStr}",
  "הערות": "כל הערה רלוונטית – טון, אווירה, נושאים חריגים, או ריק"
}

כללים חשובים:
- השתמש בעברית בלבד בערכים
- אם אינך בטוח בשדה, השאר ריק ("")
- אל תמציא מידע שאינו בתמלול
- "ניימדרופינג" – שמות בלבד, לא תיאורים`;
}

// ── POST /api/process ─────────────────────────────────────────────────────────
app.post('/api/process', upload.single('file'), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'לא התקבל קובץ' });
  }

  const tmpPath = req.file.path;
  const originalName = req.file.originalname;

  try {
    // 1. Transcribe with Whisper
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');

    const sendEvent = (type, data) => {
      res.write(`data: ${JSON.stringify({ type, ...data })}\n\n`);
    };

    sendEvent('status', { message: 'מתמלל את הקובץ עם Whisper...' });

    const audioStream = fs.createReadStream(tmpPath);
    // Whisper needs the correct extension to detect format
    audioStream.path = tmpPath + path.extname(originalName);

    const whisperResponse = await openai.audio.transcriptions.create({
      file: audioStream,
      model: 'whisper-1',
      language: 'he',
      response_format: 'verbose_json',
    });

    const transcription = whisperResponse.text;
    const durationSec = whisperResponse.duration || null;

    sendEvent('transcription', { text: transcription, duration: durationSec });
    sendEvent('status', { message: 'מנתח עם Claude...' });

    // 2. Analyze with Claude
    const prompt = buildPrompt(transcription, originalName, durationSec);

    const claudeResponse = await anthropic.messages.create({
      model: 'claude-opus-4-6',
      max_tokens: 1024,
      messages: [{ role: 'user', content: prompt }],
    });

    const rawJson = claudeResponse.content[0].text.trim();

    let fields;
    try {
      fields = JSON.parse(rawJson);
    } catch {
      // Claude sometimes wraps in ```json ... ```
      const match = rawJson.match(/```(?:json)?\s*([\s\S]*?)```/);
      if (match) {
        fields = JSON.parse(match[1].trim());
      } else {
        throw new Error('Claude החזיר פורמט לא צפוי: ' + rawJson.slice(0, 200));
      }
    }

    // 3. Build CSV row in the correct column order
    const columns = [
      'נושא_ראשי',
      'תאריך_שידור',
      'מדיה',
      'גוף_תקשורת',
      'שם_התכנית',
      'סוג_אייטם',
      'מראיין',
      'סיווג',
      'נושאים',
      'מילות_מפתח',
      'ניימדרופינג',
      'משך',
      'הערות',
    ];

    const csvRow = columns.map(col => csvCell(fields[col] ?? '')).join(',');

    sendEvent('result', { csv: csvRow, fields });
    sendEvent('done', {});
    res.end();
  } catch (err) {
    console.error(err);
    // If streaming started, send error event; otherwise send JSON
    try {
      res.write(`data: ${JSON.stringify({ type: 'error', message: err.message })}\n\n`);
      res.end();
    } catch {
      res.status(500).json({ error: err.message });
    }
  } finally {
    cleanup(tmpPath);
  }
});

// ── POST /api/analyze-text ────────────────────────────────────────────────────
// Analyze a manually-pasted transcription (no file upload needed)
app.post('/api/analyze-text', async (req, res) => {
  const { transcription, filename, duration } = req.body;
  if (!transcription || !transcription.trim()) {
    return res.status(400).json({ error: 'חסר טקסט לניתוח' });
  }

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');

  const sendEvent = (type, data) => {
    res.write(`data: ${JSON.stringify({ type, ...data })}\n\n`);
  };

  try {
    sendEvent('status', { message: 'מנתח עם Claude...' });

    const durationSec = duration ? parseFloat(duration) : null;
    const prompt = buildPrompt(transcription, filename || 'ראיון', durationSec);

    const claudeResponse = await anthropic.messages.create({
      model: 'claude-opus-4-6',
      max_tokens: 1024,
      messages: [{ role: 'user', content: prompt }],
    });

    const rawJson = claudeResponse.content[0].text.trim();
    let fields;
    try {
      fields = JSON.parse(rawJson);
    } catch {
      const match = rawJson.match(/```(?:json)?\s*([\s\S]*?)```/);
      if (match) fields = JSON.parse(match[1].trim());
      else throw new Error('Claude החזיר פורמט לא צפוי');
    }

    const columns = [
      'נושא_ראשי', 'תאריך_שידור', 'מדיה', 'גוף_תקשורת', 'שם_התכנית',
      'סוג_אייטם', 'מראיין', 'סיווג', 'נושאים', 'מילות_מפתח',
      'ניימדרופינג', 'משך', 'הערות',
    ];
    const csvRow = columns.map(col => csvCell(fields[col] ?? '')).join(',');

    sendEvent('result', { csv: csvRow, fields });
    sendEvent('done', {});
    res.end();
  } catch (err) {
    console.error(err);
    res.write(`data: ${JSON.stringify({ type: 'error', message: err.message })}\n\n`);
    res.end();
  }
});

// ── Start ─────────────────────────────────────────────────────────────────────
// Ensure uploads directory exists
fs.mkdirSync('uploads', { recursive: true });

app.listen(PORT, () => {
  console.log(`✅ השרת פועל על http://localhost:${PORT}`);
});
