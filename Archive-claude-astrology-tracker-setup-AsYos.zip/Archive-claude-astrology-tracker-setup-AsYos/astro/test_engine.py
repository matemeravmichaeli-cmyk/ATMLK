"""
Verification test for the astrological engine.
Checks known positions against Swiss Ephemeris output.
Run: python test_engine.py
"""
import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

from engine.positions import all_positions, planet_position, julian_day
from engine.aspects import calculate_aspects, angular_separation

RESET = "\033[0m"
GREEN = "\033[32m"
RED   = "\033[31m"
BOLD  = "\033[1m"

def ok(msg): print(f"  {GREEN}✓{RESET} {msg}")
def fail(msg): print(f"  {RED}✗{RESET} {msg}"); sys.exit(1)


def test_saturn_position():
    """Saturn should be ~7.45° Aries on April 16, 2026 at noon UT."""
    print(f"\n{BOLD}Test 1: Saturn position – April 16, 2026{RESET}")
    jd = julian_day(2026, 4, 16, 12.0)
    p = planet_position("saturn", jd)

    print(f"  Saturn: {p.label()}  (lon={p.longitude:.4f}°)")
    assert p.sign == "Aries", f"Expected Aries, got {p.sign}"
    assert 6.0 <= p.degree <= 9.0, f"Expected 6–9° Aries, got {p.degree:.2f}°"
    ok(f"Saturn at {p.label()} ✓  (expected ~7° Aries)")


def test_all_planets():
    """All 10 bodies should return valid positions."""
    print(f"\n{BOLD}Test 2: All planet positions – April 16, 2026{RESET}")
    jd = julian_day(2026, 4, 16, 12.0)
    positions = all_positions(jd)

    for name, p in positions.items():
        assert 0 <= p.longitude < 360, f"{name} longitude out of range: {p.longitude}"
        assert p.sign in [
            "Aries","Taurus","Gemini","Cancer","Leo","Virgo",
            "Libra","Scorpio","Sagittarius","Capricorn","Aquarius","Pisces"
        ]
        print(f"    {name:10s}  {p.label():35s}  lon={p.longitude:8.4f}°  speed={p.speed:+.4f}°/d")

    ok("All 10 planets returned valid positions")


def test_angular_separation():
    """Test the shortest-arc calculation."""
    print(f"\n{BOLD}Test 3: Angular separation utility{RESET}")
    cases = [
        (0, 180, 180),
        (10, 350, 20),
        (90, 270, 180),
        (45, 135, 90),
        (350, 10, 20),
    ]
    for lon1, lon2, expected in cases:
        result = angular_separation(lon1, lon2)
        assert abs(result - expected) < 0.0001, f"sep({lon1},{lon2}) = {result}, expected {expected}"
    ok("All angular separation cases correct")


def test_aspects():
    """Aspects for April 16, 2026 – just verify they parse and sort."""
    print(f"\n{BOLD}Test 4: Aspect calculation – April 16, 2026{RESET}")
    jd = julian_day(2026, 4, 16, 12.0)
    positions = all_positions(jd)
    aspects = calculate_aspects(positions)

    print(f"  Found {len(aspects)} aspects within orb:")
    for a in aspects:
        print(f"    {a.description()}")

    assert len(aspects) > 0, "Expected at least one aspect"
    # Verify sorted by orb ascending
    for i in range(len(aspects) - 1):
        assert aspects[i].orb <= aspects[i+1].orb
    ok(f"{len(aspects)} aspects found, sorted by orb ✓")


def test_retrograde_detection():
    """Planets known to be retrograde on specific dates."""
    print(f"\n{BOLD}Test 5: Retrograde detection{RESET}")
    # Mercury retrograde around late Jan 2026 (check a planet with known status)
    jd = julian_day(2026, 4, 16, 12.0)
    positions = all_positions(jd)
    for name, p in positions.items():
        status = "℞ (retrograde)" if p.retrograde else "direct"
        print(f"    {name:10s}  {status}  speed={p.speed:+.4f}°/d")
    ok("Retrograde detection ran without error")


if __name__ == "__main__":
    print(f"{BOLD}=== Astrological Engine Verification ==={RESET}")
    test_saturn_position()
    test_all_planets()
    test_angular_separation()
    test_aspects()
    test_retrograde_detection()
    print(f"\n{GREEN}{BOLD}All tests passed.{RESET}\n")
